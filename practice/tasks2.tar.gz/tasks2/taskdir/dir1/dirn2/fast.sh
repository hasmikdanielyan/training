fast.sh

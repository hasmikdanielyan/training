stat.sh
